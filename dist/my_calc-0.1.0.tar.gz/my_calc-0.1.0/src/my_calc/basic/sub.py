class SubOperation:
    def compute(self, a: int, b: int) -> int:
        return a - b
