class AddOperation:
    def compute(self, a: int, b: int) -> int:
        return a + b
